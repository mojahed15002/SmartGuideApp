import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'places_repository.dart';


final PlacesRepository placesRepo = FirestorePlacesRepository();
class ExplorePage extends StatefulWidget {
  const ExplorePage({super.key});

  @override
  State<ExplorePage> createState() => _ExplorePageState();
}

class _ExplorePageState extends State<ExplorePage> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      appBar: AppBar(
        title: const Text('استكشف الأماكن'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: TextField(
              decoration: const InputDecoration(
                hintText: 'ابحث باسم المكان أو المدينة أو الفئة...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: (v) => setState(() => _query = v.trim()),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: StreamBuilder<List<Place>>(
              stream: placesRepo.watchAll(),
              builder: (context, snapshot) {
                final places = snapshot.data ?? const <Place>[];
                final filtered = _filter(places, _query);

                if (snapshot.connectionState == ConnectionState.waiting && places.isEmpty) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (filtered.isEmpty) {
                  return const Center(child: Text('لا توجد نتائج.'));
                }

                if (uid == null) {
                  // بدون مستخدم: نعرض القائمة فقط
                  return _PlacesList(
  places: filtered,
  favorites: const {},
  onToggleFavorite: (_, __) async { _needLogin(context); }, // ← الآن Future<void>
);
}

                // مع مستخدم: نراقب المفضلة
                return StreamBuilder<Set<String>>(
                  stream: placesRepo.watchFavorites(uid),
                  builder: (context, favSnap) {
                    final favs = favSnap.data ?? <String>{};
                    return _PlacesList(
                      places: filtered,
                      favorites: favs,
                      onToggleFavorite: (placeId, willSet) async {
                        await placesRepo.toggleFavorite(uid, placeId, willSet);
                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  List<Place> _filter(List<Place> list, String query) {
    if (query.isEmpty) return list;
    final q = query.toLowerCase();
    return list.where((p) {
      return p.name.toLowerCase().contains(q) ||
             p.city.toLowerCase().contains(q) ||
             p.category.toLowerCase().contains(q);
    }).toList();
  }

  void _needLogin(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('سجّل الدخول لحفظ المفضلة')),
    );
  }
}

class _PlacesList extends StatelessWidget {
  final List<Place> places;
  final Set<String> favorites;
  final Future<void> Function(String placeId, bool setFavorite) onToggleFavorite;

  const _PlacesList({
    required this.places,
    required this.favorites,
    required this.onToggleFavorite,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      itemCount: places.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        final p = places[i];
        final isFav = favorites.contains(p.id);
        return InkWell(
          onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => PlaceDetailsPage(place: p)));
          },
          child: Card(
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(14),
                    bottomLeft: Radius.circular(14),
                  ),
                  child: AspectRatio(
                    aspectRatio: 1.2,
                    child: Image.network(
                      p.imageUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const ColoredBox(
                        color: Color(0x11000000),
                        child: Center(child: Icon(Icons.photo, size: 32)),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(p.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 4),
                        Text('${p.city} • ${_categoryLabel(p.category)}', style: const TextStyle(fontSize: 13)),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            const Icon(Icons.star, size: 16),
                            const SizedBox(width: 4),
                            Text(p.rating.toStringAsFixed(1)),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                IconButton(
                  tooltip: isFav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة',
                  onPressed: () => onToggleFavorite(p.id, !isFav),
                  icon: Icon(isFav ? Icons.favorite : Icons.favorite_border),
                ),
                const SizedBox(width: 4),
              ],
            ),
          ),
        );
      },
    );
  }

  String _categoryLabel(String c) {
    switch (c) {
      case 'park': return 'حديقة';
      case 'museum': return 'متحف';
      case 'cafe': return 'مقهى';
      default: return c;
    }
  }
}

class PlaceDetailsPage extends StatelessWidget {
  final Place place;
  const PlaceDetailsPage({super.key, required this.place});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(place.name)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: AspectRatio(
              aspectRatio: 16/9,
              child: Image.network(
                place.imageUrl,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const ColoredBox(
                  color: Color(0x11000000),
                  child: Center(child: Icon(Icons.photo, size: 42)),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              const Icon(Icons.location_on_outlined, size: 18),
              const SizedBox(width: 6),
              Text('${place.city} • ${place.category}'),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.star, size: 18),
              const SizedBox(width: 6),
              Text('التقييم: ${place.rating.toStringAsFixed(1)}'),
            ],
          ),
          const SizedBox(height: 12),
          Text(place.description),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: () {
              // لاحقًا: افتح على الخريطة أو وجّه لصفحة "القريبة مني" مع focus
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('سيتم إضافة عرض الموقع على الخريطة قريبًا')),
              );
            },
            icon: const Icon(Icons.map_outlined),
            label: const Text('عرض على الخريطة'),
          ),
        ],
      ),
    );
  }
}
