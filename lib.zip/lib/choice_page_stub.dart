import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'theme_notifier.dart';
import 'pages/choice_page_redirect.dart';

class ChoicePageStub extends StatelessWidget {
  final ThemeNotifier themeNotifier;
  const ChoicePageStub({super.key, required this.themeNotifier});

  @override
  Widget build(BuildContext context) {
    final cards = [
      _HubCard(
        title: 'استكشف الأماكن',
        icon: Icons.travel_explore,
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ChoicePageRedirect(themeNotifier: themeNotifier),
            ),
          );
        },
      ),
      _HubCard(
        title: 'القريبة مني',
        icon: Icons.my_location,
        onTap: () => Navigator.pushNamed(context, '/nearby'),
      ),
      _HubCard(
        title: 'المفضلة',
        icon: Icons.favorite,
        onTap: () => Navigator.pushNamed(context, '/favorites'),
      ),
      _HubCard(
        title: 'الإعدادات',
        icon: Icons.settings,
        onTap: () => Navigator.pushNamed(context, '/settings'),
      ),
      _HubCard(
        title: 'تسجيل الخروج',
        icon: Icons.logout,
        onTap: () async {
          await FirebaseAuth.instance.signOut();
          if (context.mounted) Navigator.popUntil(context, (r) => r.isFirst);
        },
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('المرشد السياحي الذكي'),
        actions: [
          // زر الثيم الجديد
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: InkWell(
              borderRadius: BorderRadius.circular(40),
              onTap: () => themeNotifier.toggleTheme(),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.deepOrange, Colors.orangeAccent],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.orange.withOpacity(0.5),
                      blurRadius: 8,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(8),
                child: Icon(
                  Theme.of(context).brightness == Brightness.dark
                      ? Icons.wb_sunny_rounded
                      : Icons.nightlight_round,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          // 🔸 الزر البرتقالي المستوحى من صفحة الترحيب
          
        ],
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: cards.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.1,
        ),
        itemBuilder: (_, i) => cards[i],
      ),
    );
  }
}

class _HubCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback onTap;
  const _HubCard({required this.title, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Ink(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: Theme.of(context).colorScheme.surface,
          boxShadow: kElevationToShadow[2],
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 38),
              const SizedBox(height: 10),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

class ChoicePage extends ChoicePageStub {
  const ChoicePage({super.key, required super.themeNotifier});
}
