import 'package:flutter/material.dart';
import '../theme_notifier.dart';
import '../choice_page_stub.dart';
import '../sign_in_panel.dart';

class WelcomePage extends StatelessWidget {
  final ThemeNotifier themeNotifier;

  const WelcomePage({super.key, required this.themeNotifier});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          // زر الثيم الجديد
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: InkWell(
              borderRadius: BorderRadius.circular(40),
              onTap: () => themeNotifier.toggleTheme(),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.deepOrange, Colors.orangeAccent],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.orange.withOpacity(0.5),
                      blurRadius: 8,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(8),
                child: Icon(
                  Theme.of(context).brightness == Brightness.dark
                      ? Icons.wb_sunny_rounded
                      : Icons.nightlight_round,
                  color: Colors.white,
                ),
              ),
            ),
          ),
           // 🔥 زر التبديل الجديد
        ],
      ),

      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "مرحباً بك في مرشدك السياحي الخاص👋",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 40),
            SignInPanel(themeNotifier: themeNotifier),
            const SizedBox(height: 20),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                padding: const EdgeInsets.symmetric(
                  horizontal: 40,
                  vertical: 15,
                ),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ChoicePage(themeNotifier: themeNotifier)),
                );
              },
              child: const Text("انطلق😎"),
            ),
          ],
        ),
      ),
    );
  }
}
